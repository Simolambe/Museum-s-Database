create sequence sequenza_utenti
increment by 1
start with 1;

create sequence sequenza_opere
increment by 1
start with 1;

create sequence sequenza_raccomandazioni
increment by 1
start with 1;

create sequence sequenza_storie
increment by 1
start with 1;

create sequence sequenza_artisti
increment by 1
start with 1;


create table Utenti(
	id_utente bigint default nextval('sequenza_utenti'),
	email varchar(40) not null,
	data_di_nascita date not null,
    nome varchar(40) not null,
	cognome varchar(40) not null,
	genere char,
	tipo int not null,
	
	constraint pk_utenti primary key (id_utente),
	constraint unq_ute_email unique (email),
	constraint chk_ute_tipo check(tipo between 0 and 2)
);

create table Artisti(
	id_artista bigint default nextval('sequenza_artisti'),
	nome varchar(40) not null,
	cognome varchar(40) not null,
	citta_di_nascita varchar(40) not null,
	anno_di_nascita date not null,
	citta_di_morte varchar(40),
	anno_di_morte date,
	movimento_artistico varchar(40),
	
	constraint pk_artisti primary key (id_artista)
);


create table Storie(
	id_storia bigint default nextval('sequenza_storie'),
    titolo varchar(40) not null,
	utente bigint not null,
	inizio timestamp not null,
	fine timestamp not null,
	
	constraint pk_storie primary key (id_storia),
	constraint fk_sto_utente foreign key (utente) references Utenti(id_utente)
		on update cascade 
		on delete cascade
);

create table Opere(
	codice bigint default nextval('sequenza_opere'),
	autore bigint not null,
	titolo varchar(90) not null,
    tecnica varchar(90),
	descrizione text,
	descrizione_audio bytea,
	dimensioni varchar(90),
	anno_di_realizzazione varchar(5) not null,
	online boolean not null,
	
	constraint pk_opere primary key (codice),
	constraint fk_ope_autore foreign key (autore) references Artisti(id_artista)
		on update cascade
		on delete cascade
);

create table Interpretazioni(
	storia bigint,
	opera bigint,
	hashtag varchar(90),
    emoji varchar(10),
	D1 varchar(90),
	D2 varchar(90),
	D3 varchar(90),
	
	constraint pk_interpretazioni primary key (storia, opera),
	constraint fk_int_storia foreign key (storia) references Storie(id_storia)
		on update cascade
		on delete cascade,
	constraint fk_int_opera foreign key (opera) references Opere(codice)
		on update cascade
		on delete cascade
);


create table Raccomandazioni(
	id_raccomandazione bigint default nextval('sequenza_raccomandazioni'),
	storia bigint,
	simile bigint,
	uguale bigint,
    opposta bigint,
	
	constraint pk_raccomandazioni primary key(id_raccomandazione, storia),
	constraint fk_rac_storia foreign key (storia) references Storie(id_storia)
		on update cascade
		on delete cascade,
	constraint fk_rac_opposta foreign key (opposta) references Storie(id_storia)
		on update cascade
		on delete cascade,
	constraint fk_rac_simile foreign key (simile) references Storie(id_storia)
		on update cascade
		on delete cascade,
	constraint fk_rac_uguale foreign key (uguale) references Storie(id_storia)
		on update cascade
		on delete cascade
);

create table Votazioni(
	utente bigint,
	storia bigint,
	voto int not null,
	
	constraint pk_votazioni primary key(utente,storia),
	constraint fk_vot_utente foreign key (utente) references Utenti(id_utente)
		on update cascade
		on delete cascade,
	constraint fk_vot_storia foreign key (storia) references Storie(id_storia)
		on update cascade
		on delete cascade,
	constraint chk_vot_voto check(voto between 0 and 10)
);
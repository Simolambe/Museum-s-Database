select setval('sequenza_utenti', 1, false);
select setval('sequenza_artisti', 1, false);
select setval('sequenza_storie', 1, false);
select setval('sequenza_opere', 1, false);
select setval('sequenza_raccomandazioni', 1, false);

INSERT INTO Utenti (email, nome, cognome, genere, data_di_nascita, tipo)
VALUES
    ('mariabianchi@mail.com', 'Maria', 'Bianchi', 'F', '1993-07-10', '2'),
    ('giovanninero@mail.com', 'Giovanni', 'Nero', 'M', '1998-03-15', '2'),
    ('francescarossi@mail.com', 'Francesca', 'Rossi', 'F', '2000-09-20', '1'),
    ('andreadibiase@mail.com', 'Andrea', 'Di Biase', 'M', '1995-12-08', '0'),
    ('sarasalvatore@mail.com', 'Sara', 'Salvatore', 'F', '1999-11-05', '2');

INSERT INTO Storie (titolo, utente, inizio, fine)
VALUES
    ('Viaggi', '1', '2023-02-28 09:20:15', '2023-02-28 09:21:30'),
    ('Natura', '2', '2023-07-10 14:45:22', '2023-07-10 14:46:10'),
    ('Avventure', '3', '2023-10-15 11:30:40', '2023-10-15 11:31:55'),
    ('Amicizia', '4', '2023-12-05 19:05:00', '2023-12-05 19:06:15'),
    ('Riflessioni', '5', '2023-12-25 22:10:30', '2023-12-25 22:11:45');

INSERT INTO Artisti(nome, cognome, citta_di_nascita, anno_di_nascita, citta_di_morte, anno_di_morte, movimento_artistico)
VALUES
    ('Alberto', 'Burri', 'Città di Castello (PG)', '1915-03-12', 'Nizza', '1995-02-15', 'Arte Informale'),
    ('Giuseppe', 'Capogrossi', 'Roma', '1900-03-07', 'Roma', '1972-10-09', 'Arte Informale'),
    ('Enzo', 'Mari', 'Novara', '1932-04-27', 'Milano', '2020-10-19', 'Design'),
    ('Alberto', 'Magnelli', 'Firenze', '1888-07-01', 'Meudon', '1971-04-20', 'Arte Astratta'),
    ('Felice', 'Casorati', 'Novara', '1883-12-04', 'Torino', '1963-03-01', 'Novecento Italiano'),
    ('Vincenzo', 'Gemito', 'Napoli', '1852-07-16', 'Napoli', '1929-03-01', 'Realismo'),
    ('Vincenzo', 'Vela', 'Ligornetto', '1820-03-03', 'Mendrisio', '1891-10-03', 'Realismo'),
    ('Giuseppe', 'Penone', 'Garessio', '1947-04-03', NULL, NULL, 'Arte Povera');

INSERT INTO Opere(autore, titolo, descrizione, descrizione_audio, tecnica, dimensioni, anno_di_realizzazione, online)
VALUES
    (1, 'Sacco Rosso', 'Astratto su tela di sacco', null, 'Olio su tela', 'cm 85,7x100', '1953', true),
    (2, 'Superficie 141', 'Opera astratta su tela', null, 'Olio su tela', '174,5 x 87,5 cm', '1955', false),
    (3, 'STRUTTURA n. 444', 'Scultura di carta e plexiglas', null, 'Carta e plexiglas', '43 x 32 x 8,5 cm', '1958', true),
    (4, 'Lumière inondante', 'Dipinto su tela', null, 'Olio su tela', '97,5 x 130,5 cm', '1950', true),
    (5, 'Suonatore di chitarra', 'Ritratto di uomo suonatore di chitarra', null, 'Olio su tela', '83 x 67 cm', '1924', false),
    (6, 'Napoli', 'Veduta di Napoli con fontana del Maschio Angioino', null, 'Marmo', '99 x 62 x 54 cm', '1888', false),
    (7, 'Monumento funebre a Leonardo Fea', 'Scultura in marmo raffigurante il busto di Leonardo Fea', null, 'Marmo', '101 x 64 x 35 cm', '1922', false),
    (8, 'Soffio di foglie', 'Quadro rappresentante un soffio di vento tra le foglie', null, 'Pittura', '400 x 180 cm', '2002', true);


insert into Votazioni(utente, storia, voto)
values (1, 4, 7),
	   (2, 3, 6),
	   (1, 1, 10),
	   (4, 2, 8),
	   (5, 4, 7),
	   (4, 5, 5);

    insert into Interpretazioni(storia, opera, emoji, hashtag, D1, D2, D3)
values (3, 1, '😍', null, null, null, null),
	   (4, 6, '😍', '#scultura', 'antica Grecia', 'scultori antichi', null),
       (1, 7, '😮', '#bellezza', 'giovinezza', 'infanzia', null),
	   (1, 8, '😐', '#futurismo', 'cultura', 'poesia', null),
       (2, 2, '🤔', '#monocromatico', 'passare del tempo', null, null),
	   (2, 3, '😍', '#astratto', 'bosco', 'natura', null),
       (3, 2, '😥', null, null, null, null),
	   (4, 4, '😵', '#wow', 'casa', null, 'ipnotizzato');

insert into Raccomandazioni(storia, opposta, simile, uguale)
values (2, 1, 3, null),
	   (3, 4, 1, null),
	   (4, 3, 2, null),
	   (1, 2, null, null),
	   (4, 3, null, null);

select setval('sequenza_utenti', (select count (*) from Utenti), true);
select setval('sequenza_storie', (select count (*) from Storie), true);
select setval('sequenza_opere', (select count (*) from Opere), true);
select setval('sequenza_raccomandazioni', (select count (*) from Raccomandazioni), true);
select setval('sequenza_artisti', (select count (*) from Artisti), true);

-- viene inserito un nuovo utente
insert into Utenti (email, nome, cognome, genere, data_di_nascita, tipo)
values ('luigiverdi@mail.com', 'Luigi', 'Verdi', 'M', '1991-01-02', 1);

-- viene creata una nuova storia
insert into Storie (titolo, utente, inizio, fine)
values ('Allegria', '5', '2023-01-15 17:12:12', '2023-01-15 17:13:32');

-- viene inserito un nuovo autore
INSERT INTO Artisti(nome, cognome, citta_di_nascita, anno_di_nascita, citta_di_morte, anno_di_morte, movimento_artistico)
VALUES ('Amedeo','Modigliani','Livorno','1884-07-12','Parigi','1920-01-24','arte moderna');

--viene creata una nuova opera
insert INTO Opere(autore, titolo, descrizione, descrizione_audio, tecnica, dimensioni, anno_di_realizzazione, online)
VALUES (9,'Amazzone','rappresenta una delle icone della sua arte e ne incarna lo stile riconoscibile e affascinante',NULL,'olio su tela','92x65','1909',false);

-- selezione di opere e commento di esse
insert into Interpretazioni (storia, opera, emoji, hashtag, d1, d2, d3)
values (3, 4, '😊', '#contento', null, null, null);

-- raccomandazione di una storia 
insert into Raccomandazioni (storia, opposta, simile, uguale)
values (3, 2, 1, null);

-- votazione della storia di un altro utente
insert into Votazioni (utente, storia, voto)
values (4, 3, 9);

-- cancellazione di un utente da parte di un curatore
delete from Utenti where id_utente = 2;

-- cancellazione di una storia da parte di un curatore
delete from Storie where id_storia = 5;

